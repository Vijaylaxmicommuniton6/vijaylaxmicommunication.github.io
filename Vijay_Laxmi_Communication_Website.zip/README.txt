VIJAY LAXMI COMMUNICATION PVT. LTD.
Website files

Open index.html in a browser to preview the website.
For a public website link, upload the folder to a web hosting service and connect your domain.
Replace the VL logo block in index.html with your original logo when available.
